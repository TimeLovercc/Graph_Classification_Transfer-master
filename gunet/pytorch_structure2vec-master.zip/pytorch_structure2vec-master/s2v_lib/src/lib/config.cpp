#include "config.h"

bool cfg::msg_average = false;